export const contractAddress =
  'erd1qqqqqqqqqqqqqpgqc4gpuj5ap7hzumf59ua4dpzd23dvuh2fj0wqqfmuvm';

export const dAppName = 'NFT MINT AND STAKE';

export const contractMint = '';
