const txStatus = {
  pending: 'Pending',
  notExecuted: 'Not Executed',
  success: 'Success',
  fail: 'Failed'
};

export default txStatus;
